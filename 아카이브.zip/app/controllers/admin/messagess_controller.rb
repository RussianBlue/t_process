class Admin::MessagessController < ApplicationController
  def index
  end

  def destory
  end
end
