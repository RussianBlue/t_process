module Admin::CurriculumsHelper
end
