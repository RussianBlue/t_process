module Admin::BoardsHelper
end
