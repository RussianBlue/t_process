class ProgressType < ActiveRecord::Base
	belongs_to :progresses
end
