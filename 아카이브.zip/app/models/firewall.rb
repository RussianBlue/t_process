class Firewall < ActiveRecord::Base
end
