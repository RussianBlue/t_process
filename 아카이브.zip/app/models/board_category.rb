class BoardCategory < ActiveRecord::Base
	belongs_to :boards
end
