# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
TProcess::Application.config.secret_key_base = '0aa0d9563d3eb1e4c884c451decad399ccd605c99b5c0965c2218d7997cf73f0f34a9dd51f1c6757a7a36834a53f40611e4f16ee9f816bf435fd5e5b2b6b6d75'
