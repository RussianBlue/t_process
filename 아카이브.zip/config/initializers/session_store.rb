# Be sure to restart your server when you modify this file.

TProcess::Application.config.session_store :cookie_store, key: '_t_process_session'
